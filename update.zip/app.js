const {
  app,
  BrowserWindow,
  webContents,
  Menu,
  ipcMain,
  nativeTheme,
  Notification,
  nativeImage,
  ipcRenderer
} = require('electron');



const url = require('url');
const path = require('path');
const ejse = require('ejs-electron');
const {
  v4: uuidv4
} = require('uuid');
const https = require('https');
const fs = require('fs');
const mkdirp = require("mkdirp");
const WindowStateManager = require('electron-window-state-manager');

var jsoncog = require(path.join(__dirname, 'package.json'));

const dateTime = require('node-datetime');

// RUTAS
var file_fecha_ruta = path.join(__dirname, 'ServerGitHub', 'data', 'fechaUpdate.text');

// VARIABLES
let mainWindow
let loading

// FECHA
// FECHA
const dt = dateTime.create();

var days = dt.format('d');
var years = dt.format('Y');

var mes = dt.format('m');

if (mes == '01') {
  var vermes = 'Enero';
} else if (mes == '02') {
  var vermes = 'Febrero';
} else if (mes == '03') {
  var vermes = 'Marzo';
} else if (mes == '04') {
  var vermes = 'Abril';
} else if (mes == '05') {
  var vermes = 'Mayo';
} else if (mes == '06') {
  var vermes = 'Junio';
} else if (mes == '07') {
  var vermes = 'Julio';
} else if (mes == '08') {
  var vermes = 'Agosto';
} else if (mes == '09') {
  var vermes = 'Septiembre';
} else if (mes == '10') {
  var vermes = 'Octubre';
} else if (mes == '11') {
  var vermes = 'Noviembre';
} else if (mes == '12') {
  var vermes = 'Diciembre';
}
// $('#getfecha').val(fecha_spanish);
// $('#getid').val(uuidv4());
var fecha_spanish = days + 'de' + vermes + '' + years;

// READY
app.on('ready', () => {
  loading = new BrowserWindow({
    icon: path.join(__dirname, 'assets/icons/win/app01.ico'),
    width: 300,
    height: 300,
    'minHeight': 300,
    'minWidth': 300,
    titleBarStyle: 'customButtonsOnHover',
    transparent: true,
    maximizable: false,
    frame: false,
    webPreferences: {
      preload: path.join(__dirname, 'preloader/loading.js'),
      nodeIntegration: true
      // contextIsolation: false
    }
  });

  // CARGAR ARCHIVO LOCAL
  loading.loadURL(url.format({
    pathname: path.join(__dirname, 'ServerGitHub/page/loading/index.ejs'),
    protocol: 'file',
    slashes: true
  }))

  //AGREGAR MENU A MAINWINDOW
  const loadingWindow = Menu.buildFromTemplate(templateMenu);
  loading.setMenu(loadingWindow);
  loading.setMenuBarVisibility(false);

  loading.on('close', () => {
    /*app.quit();*/
  })


})


function winall() {
  //DEFAULT TAMAÑO VENTANA MAINWINDOW
  const mainWindowState = new WindowStateManager('mainWindow', {
    defaultWidth: 500,
    defaultHeight: 500
  });
  mainWindow = new BrowserWindow({
    icon: path.join(__dirname, 'assets/icons/win/app01.ico'),
    width: mainWindowState.width,
    height: mainWindowState.height,
    'minHeight': 500,
    'minWidth': 500,
    x: mainWindowState.x,
    y: mainWindowState.y,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: true
      // contextIsolation: false
    }
  });


  //AGREGAR MENU A MAINWINDOW
  const menuMainWindow = Menu.buildFromTemplate(templateMenu);
  mainWindow.setMenu(menuMainWindow);
  mainWindow.setMenuBarVisibility(false);

  // SI LA APLICACION SE CERRO EN MAXIMIZE
  if (mainWindowState.maximized) {
    mainWindow.maximize();
  }

  // CARGAR ARCHIVO LOCAL
  mainWindow.loadURL(url.format({
    pathname: path.join(__dirname, 'aplication/index.ejs'),
    protocol: 'file',
    slashes: true
  }))

  mainWindow.on('close', () => {
    mainWindowState.saveState(mainWindow);
    /*app.quit();*/
  })


  // GENERAR EL AUTOCOMPLETE DEL BUSCADOR
  // RUTA FILE DATA
  const file_data_ruta = path.join(__dirname, 'aplication', 'db-json', 'data.json');
  // RUTA FILE SEARCH
  const file_search_ruta = path.join(__dirname, 'aplication', 'db-json', 'search.json');
  fs.writeFileSync(file_search_ruta, '[]', 'utf-8');
  // LEER DATA
  const file_data_leer = fs.readFileSync(file_data_ruta, 'utf-8');
  const file_search_leer = fs.readFileSync(file_search_ruta, 'utf-8');

  /*PARSE JSON*/
  let data_parse = JSON.parse(file_data_leer);
  let data_search = JSON.parse(file_search_leer);
  for (var i = 0; i < data_parse.length; i++) {
    var userrem = data_parse[i].uploader.replace(/-app/g, 'lokuedo5000');
    var newsearch = {
      Spanish: data_parse[i].titulo,
      User: userrem
    }
    data_search.push(newsearch);
    fs.writeFileSync(file_search_ruta, JSON.stringify(data_search, null, 2), 'utf-8');
  }
  // END
}

// CLICK DOWNLOAD
function downloadfiles(enlace) {
  var file = fs.createWriteStream(path.join(__dirname, 'ServerGitHub', 'download', 'update.zip'));
  var len = 0;

  https.get(enlace, function(res) {
    res.on('data', function(chunk) {
      file.write(chunk);
      len += chunk.length;

      // percentage downloaded is as follows
      var percent = (len / res.headers['content-length']) * 100;
      loading.webContents.send('app--progrees', percent);
    });
    res.on('end', function() {
      file.close();
    });
    file.on('close', function() {
      // the file is done downloading
      // exec('update_setup.exe');
      loading.webContents.send('app--fin', 'close');
    });
  });
}

// DESCARGAR ARCHIVOS
function clickDownload(enlace) {
  var file = fs.createWriteStream(path.join(__dirname, 'ServerGitHub', 'download', 'update.zip'));
  var len = 0;

  https.get(enlace, function(res) {
    res.on('data', function(chunk) {
      file.write(chunk);
      len += chunk.length;

      // percentage downloaded is as follows
      var percent = (len / res.headers['content-length']) * 100;
      mainWindow.webContents.send('app--progrees-click', percent);
    });
    res.on('end', function() {
      file.close();
    });
    file.on('close', function() {
      // the file is done downloading
      // exec('update_setup.exe');
      mainWindow.webContents.send('app--fin-click', 'close');
    });
  });
}

ipcMain.on('app--download-click', (e, data) => {
  clickDownload(jsoncog.enlaces.update);
})

ipcMain.on('app--download', (e, data) => {
  // FECHA
  var moment = require('moment');
  var date = moment();

  // ARRAYS
  var datosUp = ['1/7', '2/7', '1/30', '2/30', '1', '0'];

  var tiempoDownload = jsoncog.enlaces.tiempoUpdate;

  var existeTime = datosUp.includes(tiempoDownload);
  //ACTIVE DE DOWNLOAD
  if (existeTime == true) {
    // LOAD FECHAS
    var carga_date = fs.readFileSync(file_fecha_ruta, 'utf-8');
    var cargar_fecha = carga_date.replace(/\s+/g, '');
    var day = date.day();
    // FUNCTION
    if (tiempoDownload == '1/7') {
      var dwnAct = '';
      if (day == '7') {
        var dwnAct = true;
      }
      if (dwnAct == true) {
        if (fecha_spanish == cargar_fecha) {
          winall();
          loading.close();
        } else {
          fs.writeFileSync(file_fecha_ruta, fecha_spanish, 'utf-8');
          downloadfiles(jsoncog.enlaces.update);
        }

      } else {
        winall();
        loading.close();
      }
    } else if (tiempoDownload == '2/7') {
      var dwnAct = '';
      if (day == '4') {
        var dwnAct = true;
      }
      if (dwnAct == true) {
        if (fecha_spanish == cargar_fecha) {
          winall();
          loading.close();
        } else {
          fs.writeFileSync(file_fecha_ruta, fecha_spanish, 'utf-8');
          downloadfiles(jsoncog.enlaces.update);
        }

      } else {
        winall();
        loading.close();
      }
    } else if (tiempoDownload == '1/30') {
      const dt = dateTime.create();
      var days = dt.format('d');
      if (days == '01') {
        if (fecha_spanish == cargar_fecha) {
          winall();
          loading.close();
        } else {
          fs.writeFileSync(file_fecha_ruta, fecha_spanish, 'utf-8');
          downloadfiles(jsoncog.enlaces.update);
        }
      } else {
        winall();
        loading.close();
      }
    } else if (tiempoDownload == '2/30') {
      const dt = dateTime.create();
      var days = dt.format('d');
      if (days == '15') {
        if (fecha_spanish == cargar_fecha) {
          winall();
          loading.close();
        } else {
          fs.writeFileSync(file_fecha_ruta, fecha_spanish, 'utf-8');
          downloadfiles(jsoncog.enlaces.update);
        }
      } else {
        winall();
        loading.close();
      }
    } else if (tiempoDownload == '1') {
      if (fecha_spanish == cargar_fecha) {
        winall();
        loading.close();
      }else {
        fs.writeFileSync(file_fecha_ruta, fecha_spanish, 'utf-8');
        downloadfiles(jsoncog.enlaces.update);
      }
    } else if (tiempoDownload == '0') {
      winall();
      loading.close();
    }
    // END


  }

})

// FIN DE DESCARGA
ipcMain.on('app--open-web', (e, data) => {
  if (data.run == 'app') {

    // EXTRAER ARCHIVOS
    var file_descargada = path.join(__dirname, 'ServerGitHub', 'download', 'update.zip');
    var folder_installl = path.join(__dirname, '/');
    var extract = require('extract-zip');
    var update_file = path.resolve(file_descargada);
    var install_update = path.resolve(folder_installl);

    extract(update_file, {
      dir: install_update
    }, function(err) {
      if (err) {
        console.log(err);
      } else {
        winall();
        loading.close();
      }
    })

  }else if (data.run == 'apprun') {

    // EXTRAER ARCHIVOS
    var file_descargada = path.join(__dirname, 'ServerGitHub', 'download', 'update.zip');
    var folder_installl = path.join(__dirname, '/');
    var extract = require('extract-zip');
    var update_file = path.resolve(file_descargada);
    var install_update = path.resolve(folder_installl);

    extract(update_file, {
      dir: install_update
    }, function(err) {
      if (err) {
        console.log(err);
      } else {
        
      }
    })

  }
})
//QUITAR MENU
Menu.setApplicationMenu(null);
// function lk() {
//   console.log('lokuedo5000');
// }
//
// app.setUserTasks([
//   {
//     program: process.execPath,
//     arguments: lk(),
//     iconPath: path.join(__dirname, 'assets/icons/win/web2.ico'),
//     iconIndex: 0,
//     title: 'lokuedo5000',
//     description: 'Create a new window'
//   }
// ]);


// Menu Template
var templateMenu = [{
  label: 'CoffeeWeb',
  submenu: [{
      label: 'Admin',
      accelerator: process.platform == 'darwin' ? 'command+Alt+A' : 'Ctrl+Alt+A',
      click() {
        // let db = new sqlite3.Database(path.join(__dirname, 'web/chinook.db'), (err) => {
        //   if (err) {
        //     console.error(err.message);
        //   }
        //   console.log('Connected to the chinook database.');
        // });
      }
    },
    {
      type: 'separator'
    },
    {
      label: 'Ayuda',
      click() {

      }
    },
    {
      type: 'separator'
    },
    {
      label: 'Exit',
      accelerator: process.platform == 'darwin' ? 'command+Q' : 'Ctrl+Q',
      click() {
        app.quit();
      }
    }
  ]
}];

// Reload in Development for Browser Windows
var DevTools = process.env.APP_DEV ? (process.env.APP_DEV.trim() == "true") : true;

if (DevTools) {
  templateMenu.push({
    label: 'DevTools',
    submenu: [{
        label: 'Show/Hide Dev Tools',
        accelerator: process.platform == 'darwin' ? 'Comand+D' : 'Ctrl+D',
        click(item, focusedWindow) {
          focusedWindow.toggleDevTools();
        }
      },
      {
        role: 'reload'
      }
    ]
  })
};
