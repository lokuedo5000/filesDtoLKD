// Modules
// EventEmitter
const et = require('events');
et.EventEmitter.defaultMaxListeners = 0;

// Electron
const {
  app,
  BrowserWindow,
  webContents,
  Menu,
  ipcMain,
  screen,
  dialog
} = require('electron');

// Importar Expresss
const express = require('express');
const exp = express();
// morgan
const logger = require('morgan');

// Aqui los otros Modules
const url = require('url');
const path = require('path');
const fs = require('fs');
const https = require('https');

// Modules App
const json = require(path.join(__dirname, 'data', 'js', 'json-main'));

// Package
const package = require(path.join(__dirname, 'package.json'));

// My Folder AppData
var fAppData = path.join(app.getPath('appData'), package.name);

// db main
const dbs = {};
// db timers
var timers = [];

// WebTorrent
var WebTorrent = require('webtorrent')
var client = new WebTorrent()

// Get Info Torrent
var parseTorrent = require('parse-torrent');

// get size
var filesize = require('file-size');

// Save Info Windows
const WindowStateManager = require('electron-window-state-manager');

// Verificar Files
function files(filejson, jsontext) {
  try {
    fs.readFileSync(filejson, 'utf-8');
  } catch (e) {
    // if (e.code != 'EEXIST') throw e;
    fs.writeFileSync(filejson, jsontext, 'utf-8');
  }
}

// folder
function fNew(folder) {
  try {
    fs.mkdirSync(folder);
  } catch (e) {
    if (e.code != 'EEXIST') throw e;
  }
}


// obtener port
var fileDbs = json.read(path.join(fAppData, 'json', 'db.json'));

if (fileDbs.ajustes == undefined) {
  var setPort = 3035;
}else{
  var setPort = fileDbs.ajustes.port.slice(0, 4);
}

// crear db y tablas
var filedb = path.join(fAppData, 'json', 'db.json');
json.db(filedb, ['peliculas', 'favoritos', 'lista', 'ajustes', 'trackers']);

// create
files(path.join(fAppData, 'json', 'db.json'), '{}');
files(path.join(fAppData, 'json', 'des.json'), '[]');

// create folder
fNew(path.join(fAppData, 'json'));

// Creator server
exp.set("view engine", "ejs");
exp.set('port', process.env.PORT || setPort)
exp.set('views', path.resolve(__dirname, 'data', 'views'));

// Middlewares
// exp.use(logger('dev'));
exp.use(express.urlencoded({
  extended: false
}));

// Routes
exp.use(require('./data/routes/index'));

exp.use(express.static(path.join(__dirname, 'data', 'public')));

// 404 handler
exp.use((req, res, next) => {
  res.status(404).render('404');
});

/*Arrancar Servidor*/
exp.listen(exp.get('port'), () => {
  console.log('Server is Runing...');
})
// loading
function winload() {

  // Ventana
  /*Abrir ventana por tamaño default*/
  const winState = new WindowStateManager('win', {
    defaultWidth: 500,
    defaultHeight: 500
  });
  /*Datos de la ventana*/
  win = new BrowserWindow({
    icon: path.join(__dirname, 'data', 'assets', 'icons', 'win', 'page.ico'),
    width: winState.width,
    height: winState.height,
    'minWidth': 500,
    'minHeight': 500,
    x: winState.x,
    y: winState.y,
    title: 'AppWeb',
    // titleBarStyle: 'customButtonsOnHover',
    // transparent: true,
    // maximizable: true,
    // resizable: true,
    // frame: false,
    show: false,
    webPreferences: {
      nodeIntegration: true, // is default value after Electron v5
      contextIsolation: false, // protect against prototype pollution
      enableRemoteModule: true, // turn off remote
      preload: path.join(__dirname, 'data', 'js', 'win.js') /* Archivo Preloader /script/reload/win.js */
    }
  });

  /*Add Menu*/
  const menuMainWindow = Menu.buildFromTemplate(templateMenu);
  win.setMenu(menuMainWindow);
  win.setMenuBarVisibility(false);

  // Mediante este evento muestra la ventana principal cuando está cargada y lista para mostrar
  win.once('ready-to-show', () => {
    win.show()
    // Loading Page
    var endtimers = setTimeout(function() {
      // Verificar el maximize
      if (winState.maximized) {
        win.maximize();
      }
      // Enviar loading finished
      // win.webContents.send('win-loading', 'end');
    }, 3000);

    timers.push(endtimers);
    // win.webContents.send('win-action-max', 'min');
  });

  /*Load Url*/
  // win.loadURL('http://' + readPackage.host + ':' + portDefault + '/update');
  // win.on('close', () => {
  //   winState.saveState(win);
  // })

  win.loadURL('http://' + 'localhost:' + exp.get('port'));

  win.on('close', () => {
    // close torrent
    timersend()
    // clear json
    json.clear(path.join(__dirname, 'data', 'json', 'lista.json'));
    // Guardar Datos de ventana
    winState.saveState(win);
    // Close all Win
    app.quit()
  })
}

// ventana update
function updateWin() {
  /*Datos de la ventana*/
  update = new BrowserWindow({
    icon: path.join(__dirname, 'data', 'assets', 'icons', 'win', 'page.ico'),
    width: 500,
    height: 500,
    'minWidth': 500,
    'minHeight': 500,
    title: 'Update',
    titleBarStyle: 'customButtonsOnHover',
    transparent: true,
    maximizable: false,
    resizable: false,
    frame: false,
    show: false,
    webPreferences: {
      nodeIntegration: true, // is default value after Electron v5
      contextIsolation: false, // protect against prototype pollution
      enableRemoteModule: true, // turn off remote
      preload: path.join(__dirname, 'data', 'js', 'upd.js') /* Archivo Preloader /script/reload/win.js */
    }
  });

  /*Add Menu*/
  // const menuMainWindow = Menu.buildFromTemplate(updatetemp);
  // update.setMenu(menuMainWindow);
  // update.setMenuBarVisibility(false);

  // Mediante este evento muestra la ventana principal cuando está cargada y lista para mostrar
  update.once('ready-to-show', () => {
    update.show()
  });

  update.loadURL('http://' + 'localhost:' + exp.get('port') + '/update');

  update.on('close', () => {
    // update = null;
  })


}

// Electron
/*Ready*/
app.on('ready', () => {
  setTimeout(function() {
    var fileDbs = json.read(path.join(fAppData, 'json', 'db.json'));
    if (fileDbs.ajustes.update == "automatic") {
      updateWin();
    } else {
      winload()
    }
  }, 2000);
})

// Que tipo
ipcMain.on('set-download', (e, data) => {
  if (data == "download-zip") {
    update.webContents.send('download-files', 'download-zip');
  } else if (data == "no_update") {
    winload();
    update.close();
  } else if (data == "json_file") {
    update.webContents.send('download-files', 'json_file');
  }
})

// Save
ipcMain.on('save-json', (e, data) => {
  // Datos Json
  let dbsD = json.read(path.join(fAppData, 'json', 'db.json'));
  // Update id int
  data.id = parseInt(data.id);
  // Insert
  dbsD.peliculas.push(data);
  // Save
  fs.writeFile(path.join(fAppData, 'json', 'db.json'), JSON.stringify(dbsD, null, 2), function writeJSON(err) {
    if (err) return console.log(err);
    win.webContents.send('save-json-res', 'full');
  });
})

// Save Favoritos
ipcMain.on('app-fv-save', (e, data) => {
  // Datos Json
  let dbsD = json.read(path.join(fAppData, 'json', 'db.json'));
  // Update id int
  data.id = parseInt(data.id);
  // verificar si la tabla existe
  if (dbsD.favoritos == undefined) {
    // Insert
    dbsD.favoritos = [data];
  } else {
    // Insert
    dbsD.favoritos.push(data);
  }
  // Save
  fs.writeFile(path.join(fAppData, 'json', 'db.json'), JSON.stringify(dbsD, null, 2), function writeJSON(err) {
    if (err) return console.log(err);
    win.webContents.send('save-json-res', 'full');
  });
})

// Download
ipcMain.on('get-foldder', (e, data) => {
  e.sender.send('set-folder', fAppData);
})

/*Ruta de Torrents*/
function openTorrent() {
  var options = {
    title: "Add Torrent",
    defaultPath: app.getPath('desktop'),
    filters: [{
      name: 'Torrent',
      extensions: ['torrent']
    }]
  }
  dialog.showOpenDialog(win, options).then(result => {
    if (result.canceled == false) {

      const file_art = path.join(result.filePaths[0]);

      // enviar ruta
      win.webContents.send('data-res', {
        tipo: 'ruta',
        text: file_art
      });
    }
  }).catch(err => {
    console.log(err)
  })
}

ipcMain.on('open-torrent', (e, data) => {
  openTorrent();
})

// open folder
ipcMain.on('win-folder', (e, data) => {
  // open folder
  dialog.showOpenDialog(win, {
    properties: ['openFile', 'openDirectory']
  }).then(result => {
    if (result.canceled == false) {
      if (data[0].tipo == "torrent") {
        torrentDownload(data[1], result.filePaths[0]);

      } else if (data[0].tipo == "pelismagnet") {
        pelisdownload(data[1], result.filePaths[0]);

      } else if (data[0].tipo == "torrentmagnet") {
        // pelisdownload(data[1], result.filePaths[0]);
        magnetTorrent(data[1], result.filePaths[0])
      }
    }
  }).catch(err => {
    console.log(err)
  })
})

// magnet torrent
function magnetTorrent(magnet, folder) {
  // db
  const file_db = json.read(path.join(fAppData, 'json', 'db.json'));

  var get_Tr = parseTorrent(magnet.filetorrent);

  // verificar hash
  const getcliente = client.get(get_Tr.infoHash);

  if (getcliente == null) {
    /* Get Uri */
    const uri = parseTorrent.toMagnetURI({
      infoHash: get_Tr.infoHash
    })

    // el Uri
    var theuri = uri + '&dn=' + get_Tr.dn;

    // create trackers
    var theTr_Magnet = json.unir(get_Tr.announce, file_db.trackers);

    client.add(theuri, {
      announce: theTr_Magnet,
      path: folder
    }, function(torrent) {

      const saveHdes = {
        id: torrent.infoHash,
        name: torrent.name,
        infoHash: torrent.infoHash,
        length: torrent.length,
        progress: '0%',
        received: 0,
        download: 0,
        downloadSpeed: 0,
        uploadSpeed: 0,
        archivo: magnet.filetorrent,
        endfile: false
      };

      // add json
      json.add(path.join(__dirname, 'data', 'json', 'lista.json'), saveHdes);

      // add historial
      json.add(path.join(__dirname, 'data', 'json', 'historial.json'), saveHdes);

      // reload
      win.reload();

      // reload info de el torrent
      var timerMagnet = setInterval(function() {
        const formSave = {
          id: torrent.infoHash,
          name: torrent.name,
          infoHash: torrent.infoHash,
          length: torrent.length,
          progress: (torrent.progress * 100).toFixed(1) + '%',
          received: torrent.received,
          download: torrent.downloaded,
          downloadSpeed: torrent.downloadSpeed,
          uploadSpeed: torrent.uploadSpeed,
          archivo: magnet.filetorrent,
          endfile: false
        };
        // script download
        json.update(path.join(__dirname, 'data', 'json', 'lista.json'), formSave)

        // script historial
        json.update(path.join(__dirname, 'data', 'json', 'historial.json'), formSave)

      }, 5000);

      timers.push(timerMagnet);

      // End
      torrent.on('done', function() {
        clearInterval(timerMagnet);
        // script historial
        json.add(path.join(__dirname, 'data', 'json', 'historial.json'), {
          id: torrent.infoHash,
          name: torrent.name,
          infoHash: torrent.infoHash,
          length: torrent.length,
          progress: 100 + '%',
          received: 0,
          download: torrent.length,
          downloadSpeed: 0,
          uploadSpeed: 0,
          archivo: magnet.filetorrent,
          endfile: true
        });

        // delete download
        json.jsdelete(path.join(__dirname, 'data', 'json', 'lista.json'), {
          id: torrent.infoHash
        });

        // send delete
        win.webContents.send('data-res', {
          tipo: 'delete',
          eliminar: torrent.infoHash.slice(0, 11),
          sms: tshort(torrent.name, 20)
        });

        // End Download
        const t = client.get(torrent.infoHash);
        if (t) {
          t.destroy();
        }
      })
    })
  }else {
    // enviar error
    win.webContents.send('data-res', {
      tipo: 'error',
      text: 'lo siento ya hay una descarga con este titulo'
    });
  }

}

function torrentDownload(data, folder) {
  // db
  const file_db = json.read(path.join(fAppData, 'json', 'db.json'));
  // ruta file
  const file_ruta = path.join(data.filetorrent);

  // /*Get Info Torrent*/
  var datos_torrent = parseTorrent(fs.readFileSync(file_ruta));

  // verificar hash
  const getcliente = client.get(datos_torrent.infoHash);
  if (getcliente == null) {
    /* Get Uri */
    const uri = parseTorrent.toMagnetURI({
      infoHash: datos_torrent.infoHash
    })

    // el Uri
    var theuri = uri + '&dn=' + datos_torrent.name;

    // create trackers
    var theTr = json.unir(datos_torrent.announce, file_db.trackers);
    const saveHdes = {
      id: datos_torrent.infoHash,
      name: datos_torrent.name,
      infoHash: datos_torrent.infoHash,
      length: datos_torrent.length,
      progress: '0%',
      received: 0,
      download: 0,
      downloadSpeed: 0,
      uploadSpeed: 0,
      archivo: file_ruta,
      endfile: false
    };

    // add json
    json.add(path.join(__dirname, 'data', 'json', 'lista.json'), saveHdes);

    // add historial
    json.add(path.join(__dirname, 'data', 'json', 'historial.json'), saveHdes);

    // reload
    win.reload();
    // Download
    client.add(theuri, {
      announce: theTr,
      path: folder
    }, function(torrent) {

      // reload info de el torrent
      var filetorrent = setInterval(function() {
        const formSave = {
          id: torrent.infoHash,
          name: torrent.name,
          infoHash: torrent.infoHash,
          length: torrent.length,
          progress: (torrent.progress * 100).toFixed(1) + '%',
          received: torrent.received,
          download: torrent.downloaded,
          downloadSpeed: torrent.downloadSpeed,
          uploadSpeed: torrent.uploadSpeed,
          archivo: file_ruta,
          endfile: false
        };
        // script download
        json.update(path.join(__dirname, 'data', 'json', 'lista.json'), formSave)

        // script historial
        json.update(path.join(__dirname, 'data', 'json', 'historial.json'), formSave)

      }, 5000)


      // End
      torrent.on('done', function() {
        clearInterval(filetorrent);
        // script historial
        json.add(path.join(__dirname, 'data', 'json', 'historial.json'), {
          id: torrent.infoHash,
          name: torrent.name,
          infoHash: torrent.infoHash,
          length: torrent.length,
          progress: 100 + '%',
          received: 0,
          download: torrent.length,
          downloadSpeed: 0,
          uploadSpeed: 0,
          archivo: file_ruta,
          endfile: true
        });

        // delete download
        json.jsdelete(path.join(__dirname, 'data', 'json', 'lista.json'), {
          id: torrent.infoHash
        });

        // send delete
        win.webContents.send('data-res', {
          tipo: 'delete',
          eliminar: torrent.infoHash.slice(0, 11),
          sms: tshort(torrent.name, 20)
        });

        // End Download
        const t = client.get(torrent.infoHash);
        if (t) {
          t.destroy();
        }
      })
      timers.push(filetorrent);
    })
  } else {
    // enviar error
    win.webContents.send('data-res', {
      tipo: 'error',
      text: 'lo siento ya hay una descarga con este titulo'
    });
  }
}

// download pelis
function pelisdownload(data, folder) {
  // verificar hash
  const getcliente = client.get(data.infoHash);
  if (getcliente == null) {
    /* Get Uri */
    const uri = parseTorrent.toMagnetURI({
      infoHash: data.infoHash
    })

    // el Uri
    var theuri = uri + '&dn=' + data.name;

    // Download
    client.add(theuri, {
      announce: data.announce,
      path: folder
    }, function(torrent) {

      var interval = setInterval(function() {

        // Progress
        var thprogress = (torrent.progress * 100).toFixed(1) + '';

        // enviar progreso
        const pr = {
          id: data.id,
          titulo: data.titulo,
          infoHash: data.infoHash,
          progress: thprogress,
          received: 0,
          downloadSpeed: filesize(torrent.downloadSpeed).human('si'),
          uploadSpeed: filesize(torrent.uploadSpeed).human('si')
        }

        // Envio
        win.webContents.send('app-downloading', pr);

        // console.log(thprogress);

      }, 3000)

      timers.push(interval);



      // End
      torrent.on('done', function() {

        // Ver Peli mp4
        var file = torrent.files.find(function(file) {
          return file.name.endsWith('.mp4')
        })

        // enviar progreso
        const pr = {
          id: data.id,
          titulo: data.titulo,
          infoHash: data.infoHash,
          progress: 100,
          received: 0,
          downloadSpeed: '0 kB',
          uploadSpeed: '0 kB',
          folder: torrent.path,
          path: file.path,
          portada: data.portada
        }

        // Envio
        win.webContents.send('app-downloading', pr);

        // Add Json
        json.add(path.join(fAppData, 'json', 'des.json'), {
          id: data.id,
          infoHash: data.infoHash,
          folder: path.join(torrent.path, file.path)
        })

        const t = client.get(data.infoHash);
        if (t) {
          t.destroy();
        }
        clearInterval(interval);
      })

    })
  } else {

  }
}

// close all timers
function timersend() {
  client.destroy()
  for (var i = 0; i < timers.length; i++) {
    clearTimeout(timers[i]);
  }
}

// short text
function tshort(text, num) {
  if (text.length > num) {
    return text.slice(0, num) + '...';
  } else {
    return text;
  }
}

/*Menu Clear*/
Menu.setApplicationMenu(null);

/*Menu*/
var updatetemp = [{
  label: 'Reload',
  accelerator: process.platform == 'darwin' ? 'Comand+R' : 'Ctrl+R',
  click() {
    // Reload
    update.reload();
    // loading()
  }
}, {
  label: 'Relaunch',
  accelerator: process.platform == 'darwin' ? 'Comand+Alt+R' : 'Ctrl+Alt+R',
  click() {
    app.relaunch()
    app.exit()
  }
}, {
  label: 'DevTools',
  submenu: [{
    label: 'Show/Hide Dev Tools',
    accelerator: process.platform == 'darwin' ? 'Comand+D' : 'Ctrl+D',
    click(item, focusedWindow) {
      focusedWindow.toggleDevTools();
    }
  }]
}];

/*Menu*/
var templateMenu = [{
    label: 'Reload',
    accelerator: process.platform == 'darwin' ? 'Comand+R' : 'Ctrl+R',
    click() {
      // Reload
      win.reload();
      // loading()
    }
  },
  {
    label: 'Relaunch',
    accelerator: process.platform == 'darwin' ? 'Comand+Alt+R' : 'Ctrl+Alt+R',
    click() {
      app.relaunch()
      app.exit()
    }
  },
  {
    label: 'pre',
    accelerator: process.platform == 'darwin' ? 'Comand+Alt+F' : 'Ctrl+Alt+F',
    click() {
      // close torrent
      // const t = client.get();
      // console.log(t);

    }
  }
];

// Reload in Development for Browser Windows
var DevTools = process.env.APP_DEV ? (process.env.APP_DEV.trim() == "true") : true;

if (DevTools) {
  templateMenu.push({
    label: 'DevTools',
    submenu: [{
      label: 'Show/Hide Dev Tools',
      accelerator: process.platform == 'darwin' ? 'Comand+D' : 'Ctrl+D',
      click(item, focusedWindow) {
        focusedWindow.toggleDevTools();
      }
    }]
  })
}
